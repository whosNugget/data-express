//TODO For Create and Edit: the submit button can only be pressed
//if both passwords match, a username, email, password, and answers
//to all three questions exist